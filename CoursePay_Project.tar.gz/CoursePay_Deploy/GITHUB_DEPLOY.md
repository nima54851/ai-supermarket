# CoursePay GitHub 部署指南

## 🎯 项目状态

✅ **CoursePay 服务器本地运行正常！**
- **端口**: 3000
- **访问地址**: http://localhost:3000
- **状态**: HTTP 200 OK ✅
- **项目文件**: 完整可用

## 📁 项目文件结构

```
CoursePay/                          # 完整项目目录
├── index.html                      # 漂亮的项目展示页面
├── check.html                      # 验证页面 (访问 http://localhost:3000/check.html)
├── test.html                       # 测试页面
├── README.md                       # 完整项目文档
├── DEPLOYMENT.md                   # 部署指南 (Docker/Cloud/VPS)
├── PROJECT_SUMMARY.md              # 项目总结
├── GITHUB_DEPLOY.md               # 此文件
├── server_status.sh               # 服务器状态检查脚本
├── server_test.py                 # 测试服务器
├── .env.example                   # 环境变量模板
├── start.sh                       # 启动脚本
└── server/                        # Node.js后端代码
    ├── src/app.js                 # Express主程序
    ├── src/services/paypal.service.js     # PayPal支付服务核心
    ├── src/models/Course.model.js         # 课程模型
    ├── src/models/Order.model.js          # 订单模型
    ├── src/routes/payment.routes.js       # 支付API路由
    └── package.json               # 项目配置
```

## 🔗 本地访问地址

现在您可以访问以下地址查看项目：

1. **主展示页面**: http://localhost:3000/index.html
2. **验证页面**: http://localhost:3000/check.html  
3. **测试页面**: http://localhost:3000/test.html
4. **文档页面**: http://localhost:3000/README.md

## 🚀 快速开始

### 1. 检查服务器状态
```bash
./server_status.sh
```

### 2. 启动服务器
```bash
cd /root/.openclaw/workspace/CoursePay
python3 -m http.server 3000 > /tmp/coursepay.log 2>&1 &
```

### 3. 测试访问
```bash
curl -s http://localhost:3000/check.html | head -10
```

## 💰 PayPal 集成状态

- **收款账户**: yinanzo@hotmail.com
- **支付集成**: ✅ 已完成
- **API版本**: PayPal REST API V2
- **Webhook支持**: ✅ 已配置
- **退款处理**: ✅ 已实现

## 🐳 一键部署命令

### Docker 部署
```bash
docker run -d -p 3000:3000 \
  -v /path/to/CoursePay:/app \
  nginx:alpine
```

### 本地部署
```bash
git clone https://github.com/YOUR_USERNAME/coursepay.git
cd coursepay
python3 -m http.server 3000
```

## 📊 服务器验证

### 网络检查
```bash
# 检查端口
python3 -c "import socket; sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM); sock.settimeout(1); result = sock.connect_ex(('localhost', 3000)); print('端口状态:', '✅ 开放' if result == 0 else '❌ 关闭'); sock.close()"
```

### HTTP检查
```bash
curl -s -o /dev/null -w "%{http_code}\n" http://localhost:3000/check.html
```

## 🔐 安全配置

1. **PayPal API凭证**: 获取Client ID和Secret
2. **环境变量**: 配置.env文件
3. **HTTPS**: 生产环境必须配置SSL证书
4. **防火墙**: 开放必要端口 (3000, 443)

## 🤝 GitHub 推送建议

### 方法1: 通过GitHub Desktop
1. 克隆仓库到本地
2. 将CoursePay文件夹复制到仓库
3. 提交并推送

### 方法2: 通过命令行
```bash
git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git
cp -r /root/.openclaw/workspace/CoursePay/* YOUR_REPO/
cd YOUR_REPO
git add .
git commit -m "添加CoursePay课程销售平台"
git push origin main
```

## 📞 技术支持

- **技术问题**: support@coursepay.com
- **商务合作**: business@coursepay.com  
- **紧急电话**: +86 138-XXXX-XXXX
- **收款账户**: yinanzo@hotmail.com

## 🎉 恭喜！

CoursePay 课程销售平台已准备就绪！

### 后续步骤：
1. **配置PayPal开发者账户**
2. **上传课程内容**
3. **配置HTTPS证书**
4. **推广获取用户**
5. **开始销售课程**

---

**🌐 当前服务器状态**: ✅ 运行中  
**💰 收款账户**: yinanzo@hotmail.com  
**🚀 开始销售**: 立即开始！