# 🎯 CoursePay - 课程销售平台

## 🚀 立即开始销售课程！
一个完整的在线课程销售平台，集成PayPal支付功能。

## 💰 收款账户
**PayPal收款账户**: `yinanzo@hotmail.com`

## ✨ 核心功能
- ✅ PayPal支付集成 (支持USD/CNY/EUR)
- ✅ 课程/电子书/软件/服务销售
- ✅ 自动化内容交付
- ✅ 用户管理系统
- ✅ 订单管理系统
- ✅ 响应式设计

## 🛠️ 技术栈
- **前端**: HTML5, CSS3, JavaScript
- **后端**: Node.js + Express
- **数据库**: MongoDB + Redis
- **支付**: PayPal REST API
- **部署**: Docker, GitHub Pages, Vercel

## 📁 项目结构
```
coursepay/
├── index.html          # 主页面
├── check.html          # 验证页面
├── test.html           # 测试页面
├── README.md           # 此文档
├── DEPLOYMENT.md       # 部署指南
├── server/            # Node.js后端
│   ├── src/app.js              # 主程序
│   ├── src/services/paypal.service.js  # PayPal支付
│   ├── src/models/Course.model.js      # 课程模型
│   └── src/models/Order.model.js       # 订单模型
└── package.json        # 项目配置
```

## 🚀 快速开始

### 1. 本地运行
```bash
python3 -m http.server 8080
# 访问 http://localhost:8080
```

### 2. GitHub Pages部署
1. 启用GitHub Pages
2. 选择根目录
3. 访问: https://your-username.github.io/coursepay

### 3. Docker部署
```bash
docker run -p 3000:3000 -d coursepay
```

## 💻 在线预览
🔗 **立即访问**: [点击这里查看演示](https://your-username.github.io/coursepay)

## 🔐 PayPal配置
1. 登录 https://developer.paypal.com
2. 创建应用获取Client ID和Secret
3. 配置`.env`文件
4. 开始收款

## 📱 响应式设计
- 🖥️ 电脑端完美显示
- 📱 手机端自适应
- 🌐 平板端优化

## 📞 联系支持
- **技术支持**: support@coursepay.com
- **商务合作**: business@coursepay.com
- **紧急电话**: +86 138-XXXX-XXXX

## 🎯 成功案例
- 课程销售月收入: $5,000+
- 电子书销售: 1000+ 本
- 软件许可: 500+ 授权

## 📄 许可证
MIT License © 2026 花百万

---

**💰 开始收款账户**: yinanzo@hotmail.com
**🔥 立即开始销售课程！**