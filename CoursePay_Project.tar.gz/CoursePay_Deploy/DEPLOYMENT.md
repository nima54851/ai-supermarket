# CoursePay 部署指南

## 🎯 项目概述
CoursePay 是一个专注于虚拟商品（课程、电子书、软件、服务）销售的在线平台，集成 PayPal 支付。

**PayPal 收款账户**：`yinanzo@hotmail.com`

## 🚀 快速部署

### 1. 环境要求
- Node.js 18+
- MongoDB 6+
- Redis 7+
- PayPal 开发者账户

### 2. 克隆项目
```bash
git clone https://github.com/nima54851/CoursePay.git
cd CoursePay
```

### 3. 安装依赖
```bash
cd server
npm install
```

### 4. 环境配置
```bash
# 复制环境变量示例
cp ../.env.example .env

# 编辑 .env 文件
nano .env
```

### 5. PayPal 配置
1. 登录 PayPal 开发者中心：https://developer.paypal.com
2. 创建应用，获取 Client ID 和 Secret
3. 配置 Webhook（可选）
4. 更新 `.env` 文件：
   ```
   PAYPAL_CLIENT_ID=你的ClientID
   PAYPAL_CLIENT_SECRET=你的Secret
   PAYPAL_MODE=sandbox  # 测试环境
   ```

### 6. 启动服务
```bash
# 开发环境
npm run dev

# 生产环境
npm start
```

## 🐳 Docker 部署

### Docker Compose 一键部署
```bash
# 创建 docker-compose.yml 文件
cat > docker-compose.yml << EOF
version: '3.8'

services:
  mongodb:
    image: mongo:6
    container_name: coursepay-mongodb
    ports:
      - "27017:27017"
    environment:
      MONGO_INITDB_ROOT_USERNAME: admin
      MONGO_INITDB_ROOT_PASSWORD: password
    volumes:
      - mongodb_data:/data/db
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    container_name: coursepay-redis
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    command: redis-server --appendonly yes
    restart: unless-stopped

  coursepay:
    build: .
    container_name: coursepay-api
    ports:
      - "3000:3000"
    environment:
      - MONGODB_URI=mongodb://admin:password@mongodb:27017/coursepay
      - REDIS_URL=redis://redis:6379
      - PAYPAL_CLIENT_ID=${PAYPAL_CLIENT_ID}
      - PAYPAL_CLIENT_SECRET=${PAYPAL_CLIENT_SECRET}
      - PAYPAL_MODE=${PAYPAL_MODE:-sandbox}
    depends_on:
      - mongodb
      - redis
    restart: unless-stopped
    volumes:
      - ./logs:/app/logs

volumes:
  mongodb_data:
  redis_data:
EOF

# 启动服务
docker-compose up -d
```

### Docker 镜像构建
```bash
# 构建镜像
docker build -t coursepay:latest .

# 运行容器
docker run -p 3000:3000 \
  -e MONGODB_URI=mongodb://host.docker.internal:27017/coursepay \
  -e REDIS_URL=redis://host.docker.internal:6379 \
  -e PAYPAL_CLIENT_ID=your-client-id \
  -e PAYPAL_CLIENT_SECRET=your-client-secret \
  -v $(pwd)/logs:/app/logs \
  coursepay:latest
```

## ☁️ 云平台部署

### VPS 部署（DigitalOcean/腾讯云/阿里云）
```bash
# 1. 登录服务器
ssh root@your-server-ip

# 2. 安装依赖
apt update && apt install -y nodejs npm mongodb redis nginx

# 3. 配置防火墙
ufw allow 22
ufw allow 80
ufw allow 443
ufw allow 3000
ufw enable

# 4. 部署应用
git clone https://github.com/nima54851/CoursePay.git
cd CoursePay/server
npm ci --only=production

# 5. 配置 PM2
npm install -g pm2
pm2 start src/app.js --name coursepay
pm2 startup
pm2 save

# 6. 配置 Nginx
cat > /etc/nginx/sites-available/coursepay << EOF
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

ln -s /etc/nginx/sites-available/coursepay /etc/nginx/sites-enabled/
nginx -t && systemctl restart nginx
```

### Vercel 部署（前端）
```bash
# 1. 安装 Vercel CLI
npm i -g vercel

# 2. 部署
cd client
vercel

# 3. 设置环境变量
vercel env add PAYPAL_CLIENT_ID
vercel env add PAYPAL_CLIENT_SECRET
```

## 🔧 配置说明

### PayPal 配置
```env
# 测试环境
PAYPAL_CLIENT_ID=test_client_id
PAYPAL_CLIENT_SECRET=test_client_secret
PAYPAL_MODE=sandbox

# 生产环境
PAYPAL_CLIENT_ID=live_client_id
PAYPAL_CLIENT_SECRET=live_client_secret
PAYPAL_MODE=production
PAYPAL_RETURN_URL=https://your-domain.com/api/v1/payment/success
PAYPAL_CANCEL_URL=https://your-domain.com/api/v1/payment/cancel
```

### 数据库配置
```env
# MongoDB
MONGODB_URI=mongodb://username:password@host:port/database

# 云数据库（MongoDB Atlas）
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/database
```

### 邮件配置
```env
# Gmail 示例
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
EMAIL_FROM=noreply@your-domain.com
```

## 📊 监控和维护

### 日志查看
```bash
# 查看应用日志
tail -f logs/combined.log

# 查看错误日志
tail -f logs/error.log

# Docker 日志
docker logs coursepay-api -f
```

### 性能监控
```bash
# PM2 监控
pm2 monit
pm2 logs

# 系统资源
htop
nmon
```

### 备份和恢复
```bash
# 数据库备份
mongodump --uri="mongodb://localhost:27017/coursepay" --out=./backup

# 数据库恢复
mongorestore --uri="mongodb://localhost:27017/coursepay" ./backup/coursepay

# 文件备份
tar -czf backup-$(date +%Y%m%d).tar.gz logs/ uploads/
```

## 🔐 安全配置

### SSL 证书（Let's Encrypt）
```bash
# 安装 Certbot
apt install certbot python3-certbot-nginx

# 获取证书
certbot --nginx -d your-domain.com

# 自动续期
certbot renew --dry-run
```

### 防火墙配置
```bash
# 只开放必要端口
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow http
ufw allow https
ufw enable
```

### 安全扫描
```bash
# 安装安全工具
apt install lynis fail2ban

# 运行安全扫描
lynis audit system

# 配置 Fail2Ban
systemctl enable fail2ban
systemctl start fail2ban
```

## 🚨 故障排除

### 常见问题

#### 1. PayPal 支付失败
```bash
# 检查 PayPal 配置
echo $PAYPAL_CLIENT_ID
echo $PAYPAL_MODE

# 测试 PayPal API
curl -v https://api-m.sandbox.paypal.com/v1/oauth2/token
```

#### 2. 数据库连接失败
```bash
# 测试 MongoDB 连接
mongosh "mongodb://localhost:27017/coursepay"

# 查看 MongoDB 日志
tail -f /var/log/mongodb/mongod.log
```

#### 3. 服务无法启动
```bash
# 检查端口占用
netstat -tulpn | grep :3000

# 查看应用日志
pm2 logs coursepay

# 重新启动
pm2 restart coursepay
```

### 性能优化

#### 1. 启用 Gzip 压缩
```nginx
# Nginx 配置
gzip on;
gzip_types text/plain text/css application/json application/javascript text/xml;
```

#### 2. 配置缓存
```javascript
// Express 配置
app.use(express.static('public', {
  maxAge: '1d'
}));
```

#### 3. 数据库索引优化
```bash
# 查看慢查询
mongosh --eval "db.currentOp({'secs_running': {$gte: 5}})"
```

## 📈 扩展方案

### 水平扩展
```yaml
# Kubernetes 部署
apiVersion: apps/v1
kind: Deployment
metadata:
  name: coursepay
spec:
  replicas: 3
  selector:
    matchLabels:
      app: coursepay
  template:
    metadata:
      labels:
        app: coursepay
    spec:
      containers:
      - name: coursepay
        image: coursepay:latest
        ports:
        - containerPort: 3000
        env:
        - name: MONGODB_URI
          value: "mongodb://mongodb:27017/coursepay"
```

### CDN 集成
```javascript
// 使用 Cloudflare CDN
const CDN_URL = 'https://cdn.your-domain.com';

app.use('/uploads', express.static('uploads', {
  setHeaders: (res, path) => {
    res.set('Cache-Control', 'public, max-age=31536000');
  }
}));
```

## 💰 收款设置

### PayPal 收款账户
1. **测试环境**：使用 PayPal 沙盒账户
2. **生产环境**：使用 `yinanzo@hotmail.com` 收款
3. **手续费**：PayPal 标准费率（约 2.9% + $0.30）

### 提现设置
1. **自动提现**：配置 PayPal 自动转账到银行账户
2. **提现周期**：每日/每周/每月自动提现
3. **最小提现金额**：$10

### 税务设置
1. **销售税**：根据地区配置税率
2. **增值税**：欧盟地区需要配置 VAT
3. **发票**：自动生成电子发票

## 🆘 技术支持

### 紧急联系方式
- **技术支持**：support@coursepay.com
- **紧急电话**：+86 138-XXXX-XXXX
- **微信客服**：CoursePay_Support

### 文档资源
- [API 文档](http://localhost:3000/docs)
- [GitHub Issues](https://github.com/nima54851/CoursePay/issues)
- [PayPal 开发者文档](https://developer.paypal.com/docs)

---

**部署完成！开始你的课程销售之旅吧！** 🚀