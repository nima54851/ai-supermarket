#!/bin/bash

echo "🔄 检查 CoursePay 服务器状态..."
echo "===================================="

# 检查服务器进程
echo "📊 进程状态:"
pid=$(ps aux | grep "python.*http.server 3000" | grep -v grep | awk '{print $2}')
if [ -n "$pid" ]; then
    echo "   ✅ 服务器进程运行中 (PID: $pid)"
else
    echo "   ❌ 服务器进程未运行"
fi

# 检查端口监听
echo "🔌 网络连接:"
if python3 -c "
import socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.settimeout(1)
try:
    result = sock.connect_ex(('localhost', 3000))
    if result == 0:
        print('   ✅ 端口 3000 已开放')
    else:
        print('   ❌ 端口 3000 不可访问')
finally:
    sock.close()
"; then
    echo "   ✅ Python网络检查完成"
fi

# 测试HTTP访问
echo "🌐 HTTP访问测试:"
http_code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/check.html 2>&1 || echo "0")
if [[ "$http_code" == "200" ]]; then
    echo "   ✅ HTTP 200 OK - 访问正常"
    echo "   🔗 主页面: http://localhost:3000/index.html"
    echo "   🔗 测试页: http://localhost:3000/test.html"
    echo "   🔗 验证页: http://localhost:3000/check.html"
else
    echo "   ❌ HTTP 访问失败 (代码: $http_code)"
fi

# 显示项目信息
echo "📁 项目文件:"
echo "   • 完整项目结构在: /root/.openclaw/workspace/CoursePay/"
echo "   • PayPal支付逻辑: server/src/services/paypal.service.js"
echo "   • 课程模型: server/src/models/Course.model.js"
echo "   • 部署指南: DEPLOYMENT.md"

echo ""
echo "===================================="
echo "📌 如果需要重启服务器:"
echo "   cd /root/.openclaw/workspace/CoursePay"
echo "   pkill -f python.*http.server"
echo "   python3 -m http.server 3000 > /tmp/coursepay.log 2>&1 &"
echo ""
echo "🎯 开始使用 CoursePay 销售课程吧！"
