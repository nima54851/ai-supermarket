#!/usr/bin/env python3
"""
CoursePay服务器状态检查
"""

import http.server
import socketserver
import threading
import time
import sys

PORT = 3000

class CoursePayHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.path = '/index.html'
        return http.server.SimpleHTTPRequestHandler.do_GET(self)
    
    def log_message(self, format, *args):
        print(f"📡 [{self.log_date_time_string()}] {format % args}")

def start_server():
    """启动HTTP服务器"""
    try:
        with socketserver.TCPServer(("", PORT), CoursePayHandler) as httpd:
            print(f"🚀 CoursePay服务器已启动！")
            print(f"📌 访问地址: http://localhost:{PORT}")
            print(f"📁 项目目录: /root/.openclaw/workspace/CoursePay")
            print(f"💰 收款账户: yinanzo@hotmail.com")
            print(f"\n📊 已创建文件:")
            print("   ✅ index.html - 项目展示页面")
            print("   ✅ test.html - 功能测试页面")
            print("   ✅ server/src/ - 完整Node.js后端")
            print("   ✅ DEPLOYMENT.md - 部署指南")
            print("\n🔗 可用链接:")
            print(f"   http://localhost:{PORT}/index.html")
            print(f"   http://localhost:{PORT}/test.html")
            print(f"   http://localhost:{PORT}/README.md")
            print("\n🎯 使用Ctrl+C退出")
            httpd.serve_forever()
    except OSError as e:
        if e.errno == 98:  # 地址已使用
            print(f"❌ 端口{PORT}已被占用！")
            print("请尝试：")
            print("   1. 等待几秒钟再访问")
            print("   2. 或者运行: pkill -f python3.http.server")
            return False
        raise

if __name__ == "__main__":
    # 检查是否有已运行的服务器
    print("正在启动CoursePay服务器...")
    
    # 尝试启动
    if start_server() is False:
        # 尝试杀死进程并重新启动
        import subprocess
        subprocess.run(["pkill", "-f", "python.*http.server"])
        time.sleep(1)
        start_server()