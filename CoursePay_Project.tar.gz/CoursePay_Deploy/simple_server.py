#!/usr/bin/env python3
"""
CoursePay 简单服务器 - 确保100%能访问
"""

import os
import sys
import socket
from http.server import HTTPServer, SimpleHTTPRequestHandler
import threading
import time

class CoursePayHandler(SimpleHTTPRequestHandler):
    """自定义处理器"""
    def do_GET(self):
        """处理GET请求"""
        print(f"🔗 收到请求: {self.path}")
        return SimpleHTTPRequestHandler.do_GET(self)
    
    def log_message(self, format, *args):
        """自定义日志"""
        print(f"📡 [{time.strftime('%H:%M:%S')}] {self.address_string()} - {format % args}")

def start_server(port=3000):
    """启动HTTP服务器"""
    print(f"🚀 正在启动 CoursePay 服务器...")
    
    # 确保在正确目录
    os.chdir('/root/.openclaw/workspace/CoursePay')
    print(f"📁 工作目录: {os.getcwd()}")
    
    try:
        # 绑定所有IP地址
        server_address = ('', port)
        httpd = HTTPServer(server_address, CoursePayHandler)
        
        # 获取实际绑定的IP
        ip = socket.gethostbyname(socket.gethostname())
        print(f"✅ 服务器已启动！")
        print(f"   📍 本地地址: http://localhost:{port}")
        print(f"   📍 内部地址: http://127.0.0.1:{port}")
        print(f"   📍 网络地址: http://{ip}:{port} (如果可用)")
        print(f"\n🔗 可用链接:")
        print(f"   1. 主页: http://localhost:{port}/index.html")
        print(f"   2. 验证页: http://localhost:{port}/check.html")
        print(f"   3. 文档: http://localhost:{port}/README.md")
        
        print(f"\n🔄 服务器正在运行...按Ctrl+C停止")
        httpd.serve_forever()
        
    except PermissionError:
        print(f"❌ 权限不足！需要管理员权限")
    except OSError as e:
        print(f"❌ 端口 {port} 不可用: {e}")
        if port == 3000:
            print(f"🔄 尝试其他端口...")
            for p in [3001, 3002, 8000, 8080, 8888]:
                try:
                    start_server(p)
                    break
                except:
                    continue

def test_connection(port=3000):
    """测试服务器连接"""
    print(f"\n🔍 正在测试连接...")
    
    try:
        # 创建socket测试
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        result = sock.connect_ex(('127.0.0.1', port))
        
        if result == 0:
            print(f"✅ 端口 {port} 已开放并可以连接")
        else:
            print(f"❌ 端口 {port} 无法连接 (错误码: {result})")
        sock.close()
        
        # 尝试HTTP访问
        import urllib.request
        try:
            req = urllib.request.urlopen(f'http://127.0.0.1:{port}/check.html', timeout=3)
            print(f"✅ HTTP访问成功: 状态 {req.status}")
            return True
        except Exception as e:
            print(f"❌ HTTP访问失败: {e}")
            return False
            
    except Exception as e:
        print(f"❌ 测试时出错: {e}")
        return False

if __name__ == "__main__":
    print("=" * 50)
    print("📦 CoursePay 课程销售平台服务器")
    print("=" * 50)
    
    # 测试当前连接
    test_connection(3000)
    
    # 启动服务器
    start_server(3000)