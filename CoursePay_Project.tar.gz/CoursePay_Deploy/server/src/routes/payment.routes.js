const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const paypalService = require('../services/paypal.service');
const Order = require('../models/Order.model');
const Course = require('../models/Course.model');
const auth = require('../middleware/auth.middleware');

/**
 * @swagger
 * tags:
 *   name: Payment
 *   description: 支付相关接口
 */

/**
 * @swagger
 * /api/v1/payment/create-order:
 *   post:
 *     summary: 创建 PayPal 支付订单
 *     tags: [Payment]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - items
 *             properties:
 *               items:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     courseId:
 *                       type: string
 *                     quantity:
 *                       type: integer
 *                       default: 1
 *               currency:
 *                 type: string
 *                 default: USD
 *               couponCode:
 *                 type: string
 *     responses:
 *       200:
 *         description: 订单创建成功
 *       400:
 *         description: 请求参数错误
 *       401:
 *         description: 未授权
 */
router.post('/create-order', 
  auth,
  [
    body('items').isArray().withMessage('商品列表不能为空'),
    body('items.*.courseId').isMongoId().withMessage('商品ID格式错误'),
    body('items.*.quantity').isInt({ min: 1 }).withMessage('商品数量必须大于0'),
    body('currency').optional().isIn(['USD', 'CNY', 'EUR', 'GBP', 'JPY']),
    body('couponCode').optional().isString()
  ],
  async (req, res) => {
    try {
      // 验证请求数据
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { items, currency = 'USD', couponCode } = req.body;
      const userId = req.user.id;
      
      // 1. 获取商品信息并计算总价
      let totalAmount = 0;
      const orderItems = [];
      
      for (const item of items) {
        const course = await Course.findById(item.courseId);
        if (!course) {
          return res.status(404).json({ 
            error: `商品不存在: ${item.courseId}` 
          });
        }
        
        if (course.status !== 'published') {
          return res.status(400).json({ 
            error: `商品未上架: ${course.title}` 
          });
        }
        
        const itemPrice = course.discountedPrice || course.price;
        const itemTotal = itemPrice * item.quantity;
        
        totalAmount += itemTotal;
        
        orderItems.push({
          course: course._id,
          name: course.title,
          type: course.type,
          price: itemPrice,
          quantity: item.quantity,
          subtotal: itemTotal
        });
      }
      
      // 2. 应用优惠券（如果有）
      let discount = 0;
      if (couponCode) {
        // TODO: 实现优惠券验证逻辑
        discount = totalAmount * 0.1; // 10% 折扣示例
      }
      
      const finalAmount = totalAmount - discount;
      
      if (finalAmount <= 0) {
        return res.status(400).json({ 
          error: '订单金额不能为0' 
        });
      }
      
      // 3. 创建本地订单
      const order = new Order({
        user: userId,
        email: req.user.email,
        items: orderItems,
        subtotal: totalAmount,
        discount: discount,
        total: finalAmount,
        currency: currency,
        couponCode: couponCode,
        couponDiscount: discount,
        expiresAt: new Date(Date.now() + 15 * 60 * 1000) // 15分钟后过期
      });
      
      await order.save();
      
      // 4. 创建 PayPal 订单
      const paypalOrderData = {
        orderId: order.orderNumber,
        invoiceId: order.invoice?.number,
        currency: currency,
        total: finalAmount,
        items: orderItems.map(item => ({
          name: item.name,
          description: `虚拟商品 - ${item.type}`,
          price: item.price,
          quantity: item.quantity,
          category: 'DIGITAL_GOODS'
        })),
        customer: {
          email: req.user.email,
          name: req.user.name || req.user.email
        }
      };
      
      const paypalResult = await paypalService.createOrder(paypalOrderData);
      
      if (!paypalResult.success) {
        // 删除本地订单
        await Order.findByIdAndDelete(order._id);
        return res.status(500).json({ 
          error: '支付网关错误',
          details: paypalResult.error 
        });
      }
      
      // 5. 更新订单的 PayPal 信息
      order.paypal.orderId = paypalResult.paypalOrderId;
      await order.save();
      
      // 6. 返回支付链接
      res.json({
        success: true,
        message: '订单创建成功',
        data: {
          orderId: order.orderNumber,
          paypalOrderId: paypalResult.paypalOrderId,
          paymentUrl: paypalResult.paymentUrl,
          amount: finalAmount,
          currency: currency,
          expiresAt: order.expiresAt,
          items: orderItems.map(item => ({
            name: item.name,
            quantity: item.quantity,
            price: item.price,
            subtotal: item.subtotal
          }))
        }
      });
      
    } catch (error) {
      console.error('创建订单失败:', error);
      res.status(500).json({ 
        error: '服务器内部错误',
        message: error.message 
      });
    }
  }
);

/**
 * @swagger
 * /api/v1/payment/success:
 *   get:
 *     summary: PayPal 支付成功回调
 *     tags: [Payment]
 *     parameters:
 *       - in: query
 *         name: token
 *         schema:
 *           type: string
 *         required: true
 *         description: PayPal 订单令牌
 *       - in: query
 *         name: PayerID
 *         schema:
 *           type: string
 *         description: PayPal 付款人ID
 *     responses:
 *       200:
 *         description: 支付成功
 *       400:
 *         description: 支付失败
 */
router.get('/success', async (req, res) => {
  try {
    const { token: paypalOrderId, PayerID: payerId } = req.query;
    
    if (!paypalOrderId) {
      return res.status(400).json({ error: '缺少支付令牌' });
    }
    
    // 1. 捕获 PayPal 订单
    const captureResult = await paypalService.captureOrder(paypalOrderId);
    
    if (!captureResult.success) {
      return res.status(400).json({ 
        error: '支付捕获失败',
        details: captureResult.error 
      });
    }
    
    // 2. 查找本地订单
    const order = await Order.findOne({ 'paypal.orderId': paypalOrderId });
    
    if (!order) {
      return res.status(404).json({ error: '订单不存在' });
    }
    
    // 3. 更新订单状态
    order.paymentStatus = 'completed';
    order.orderStatus = 'confirmed';
    order.paypal = {
      ...order.paypal,
      payerId: payerId,
      captureId: captureResult.captureId,
      status: captureResult.status,
      payerEmail: captureResult.payer.email,
      payerName: captureResult.payer.name,
      paymentTime: new Date()
    };
    
    order.invoice.paidAt = new Date();
    
    await order.save();
    
    // 4. 授予课程访问权限
    const accessCode = generateAccessCode();
    await order.grantAccess({
      accessCode: accessCode,
      downloadLinks: order.items.map(item => ({
        name: item.name,
        url: `/api/v1/courses/${item.course}/download`,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30天后过期
      }))
    });
    
    // 5. 更新课程销量
    for (const item of order.items) {
      await Course.findByIdAndUpdate(item.course, {
        $inc: { salesCount: item.quantity }
      });
    }
    
    // 6. 返回成功页面
    res.render('payment-success', {
      title: '支付成功',
      order: {
        id: order.orderNumber,
        amount: order.total,
        currency: order.currency,
        items: order.items,
        accessCode: accessCode
      }
    });
    
  } catch (error) {
    console.error('支付成功回调处理失败:', error);
    res.status(500).json({ 
      error: '服务器内部错误',
      message: error.message 
    });
  }
});

/**
 * @swagger
 * /api/v1/payment/cancel:
 *   get:
 *     summary: PayPal 支付取消回调
 *     tags: [Payment]
 *     parameters:
 *       - in: query
 *         name: token
 *         schema:
 *           type: string
 *         description: PayPal 订单令牌
 *     responses:
 *       200:
 *         description: 支付已取消
 */
router.get('/cancel', async (req, res) => {
  try {
    const { token: paypalOrderId } = req.query;
    
    if (paypalOrderId) {
      // 更新订单状态为取消
      await Order.findOneAndUpdate(
        { 'paypal.orderId': paypalOrderId },
        { 
          paymentStatus: 'cancelled',
          orderStatus: 'cancelled',
          notes: '用户取消了支付'
        }
      );
    }
    
    res.render('payment-cancel', {
      title: '支付取消',
      message: '您已取消支付。如有疑问，请联系客服。'
    });
    
  } catch (error) {
    console.error('支付取消回调处理失败:', error);
    res.status(500).json({ 
      error: '服务器内部错误',
      message: error.message 
    });
  }
});

/**
 * @swagger
 * /api/v1/payment/webhook:
 *   post:
 *     summary: PayPal Webhook 回调
 *     tags: [Payment]
 *     description: PayPal 异步通知接口
 *     responses:
 *       200:
 *         description: Webhook 处理成功
 *       400:
 *         description: 验证失败
 */
router.post('/webhook', async (req, res) => {
  try {
    const signature = req.headers;
    const body = JSON.stringify(req.body);
    
    // 验证 Webhook 签名
    const isValid = await paypalService.verifyWebhookSignature(signature, body);
    
    if (!isValid) {
      return res.status(400).json({ error: 'Webhook 签名验证失败' });
    }
    
    const webhookEvent = req.body;
    
    // 处理 Webhook 事件
    const result = paypalService.handleWebhook(webhookEvent);
    
    // 根据事件类型更新订单状态
    switch (result.status) {
      case 'completed':
        // 支付完成
        const order = await Order.findOne({ 
          orderNumber: result.customId 
        });
        
        if (order) {
          order.paypal.webhookEvents.push({
            eventType: result.event,
            eventId: webhookEvent.id,
            timestamp: new Date(webhookEvent.create_time),
            data: webhookEvent
          });
          
          await order.save();
        }
        break;
        
      case 'refunded':
        // 退款完成
        await Order.findOneAndUpdate(
          { 'paypal.captureId': result.captureId },
          {
            paymentStatus: 'refunded',
            'refund.status': 'completed',
            'refund.processedAt': new Date()
          }
        );
        break;
    }
    
    console.log(`✅ Webhook 处理完成: ${result.event}`);
    res.status(200).json({ success: true });
    
  } catch (error) {
    console.error('Webhook 处理失败:', error);
    res.status(500).json({ 
      error: '服务器内部错误',
      message: error.message 
    });
  }
});

/**
 * @swagger
 * /api/v1/payment/orders/{orderId}:
 *   get:
 *     summary: 获取订单详情
 *     tags: [Payment]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: orderId
 *         schema:
 *           type: string
 *         required: true
 *         description: 订单ID
 *     responses:
 *       200:
 *         description: 订单详情
 *       404:
 *         description: 订单不存在
 */
router.get('/orders/:orderId', auth, async (req, res) => {
  try {
    const { orderId } = req.params;
    const userId = req.user.id;
    
    const order = await Order.findOne({
      orderNumber: orderId,
      user: userId
    }).populate('items.course', 'title slug coverImage');
    
    if (!order) {
      return res.status(404).json({ error: '订单不存在' });
    }
    
    res.json({
      success: true,
      data: order
    });
    
  } catch (error) {
    console.error('获取订单详情失败:', error);
    res.status(500).json({ 
      error: '服务器内部错误',
      message: error.message 
    });
  }
});

/**
 * @swagger
 * /api/v1/payment/my-orders:
 *   get:
 *     summary: 获取我的订单列表
 *     tags: [Payment]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: 订单列表
 */
router.get('/my-orders', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const orders = await Order.find({ user: userId })
      .sort({ createdAt: -1 })
      .populate('items.course', 'title coverImage');
    
    res.json({
      success: true,
      count: orders.length,
      data: orders
    });
    
  } catch (error) {
    console.error('获取订单列表失败:', error);
    res.status(500).json({ 
      error: '服务器内部错误',
      message: error.message 
    });
  }
});

// 辅助函数
function generateAccessCode() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 12; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

module.exports = router;