const paypal = require('@paypal/checkout-server-sdk');

/**
 * PayPal 支付服务
 * 收款账户：yinanzo@hotmail.com
 */

// PayPal 环境配置
let paypalClient = null;

/**
 * 初始化 PayPal 客户端
 */
const initializePayPal = () => {
  const clientId = process.env.PAYPAL_CLIENT_ID;
  const clientSecret = process.env.PAYPAL_CLIENT_SECRET;
  const environment = process.env.PAYPAL_MODE === 'production' 
    ? new paypal.core.LiveEnvironment(clientId, clientSecret)
    : new paypal.core.SandboxEnvironment(clientId, clientSecret);

  paypalClient = new paypal.core.PayPalHttpClient(environment);
  console.log(`✅ PayPal 客户端已初始化 (${process.env.PAYPAL_MODE || 'sandbox'})`);
};

/**
 * 创建订单
 * @param {Object} orderData 订单数据
 * @param {string} orderData.currency 货币代码
 * @param {number} orderData.total 总金额
 * @param {Array} orderData.items 商品列表
 * @param {Object} orderData.customer 客户信息
 * @returns {Promise<Object>} 支付链接和订单ID
 */
const createOrder = async (orderData) => {
  try {
    if (!paypalClient) initializePayPal();

    const { currency = 'USD', total, items, customer } = orderData;
    
    // 构建 PayPal 订单请求
    const request = new paypal.orders.OrdersCreateRequest();
    request.prefer('return=representation');
    
    request.requestBody({
      intent: 'CAPTURE',
      purchase_units: [
        {
          amount: {
            currency_code: currency,
            value: total.toFixed(2),
            breakdown: {
              item_total: {
                currency_code: currency,
                value: total.toFixed(2)
              }
            }
          },
          items: items.map(item => ({
            name: item.name,
            description: item.description || '',
            quantity: item.quantity.toString(),
            unit_amount: {
              currency_code: currency,
              value: item.price.toFixed(2)
            },
            category: item.category || 'DIGITAL_GOODS' // 数字商品
          })),
          custom_id: orderData.orderId,
          invoice_id: orderData.invoiceId
        }
      ],
      application_context: {
        brand_name: process.env.APP_NAME || 'CoursePay',
        landing_page: 'BILLING',
        user_action: 'PAY_NOW',
        return_url: process.env.PAYPAL_RETURN_URL,
        cancel_url: process.env.PAYPAL_CANCEL_URL,
        shipping_preference: 'NO_SHIPPING', // 无实物运输
        payment_method: {
          payer_selected: 'PAYPAL',
          payee_preferred: 'IMMEDIATE_PAYMENT_REQUIRED'
        }
      }
    });

    // 发送请求
    const response = await paypalClient.execute(request);
    const order = response.result;
    
    console.log(`✅ PayPal 订单创建成功: ${order.id}, 金额: ${total} ${currency}`);
    
    // 返回支付链接
    const approveLink = order.links.find(link => link.rel === 'approve');
    
    return {
      success: true,
      orderId: order.id,
      paypalOrderId: order.id,
      paymentUrl: approveLink ? approveLink.href : null,
      status: order.status,
      createTime: order.create_time,
      links: order.links
    };
  } catch (error) {
    console.error('❌ PayPal 订单创建失败:', error);
    return {
      success: false,
      error: error.message,
      details: error.response?.text || error.toString()
    };
  }
};

/**
 * 捕获订单（完成支付）
 * @param {string} orderId PayPal 订单ID
 * @returns {Promise<Object>} 捕获结果
 */
const captureOrder = async (orderId) => {
  try {
    if (!paypalClient) initializePayPal();

    const request = new paypal.orders.OrdersCaptureRequest(orderId);
    request.prefer('return=representation');

    const response = await paypalClient.execute(request);
    const capture = response.result;
    
    console.log(`✅ PayPal 订单捕获成功: ${orderId}`);
    
    // 提取支付者信息
    const payer = capture.payer;
    const paymentData = {
      success: true,
      orderId: capture.id,
      status: capture.status,
      captureId: capture.purchase_units[0].payments.captures[0].id,
      payer: {
        id: payer.payer_id,
        email: payer.email_address,
        name: payer.name,
        country: payer.address?.country_code
      },
      amount: capture.purchase_units[0].payments.captures[0].amount.value,
      currency: capture.purchase_units[0].payments.captures[0].amount.currency_code,
      captureTime: capture.create_time,
      updateTime: capture.update_time
    };
    
    return paymentData;
  } catch (error) {
    console.error('❌ PayPal 订单捕获失败:', error);
    return {
      success: false,
      error: error.message,
      details: error.response?.text || error.toString()
    };
  }
};

/**
 * 获取订单详情
 * @param {string} orderId PayPal 订单ID
 * @returns {Promise<Object>} 订单详情
 */
const getOrderDetails = async (orderId) => {
  try {
    if (!paypalClient) initializePayPal();

    const request = new paypal.orders.OrdersGetRequest(orderId);
    const response = await paypalClient.execute(request);
    
    return {
      success: true,
      order: response.result
    };
  } catch (error) {
    console.error('❌ 获取 PayPal 订单详情失败:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

/**
 * 处理 PayPal Webhook 事件
 * @param {Object} webhookEvent Webhook 事件数据
 * @returns {Object} 处理结果
 */
const handleWebhook = (webhookEvent) => {
  try {
    const eventType = webhookEvent.event_type;
    const resource = webhookEvent.resource;
    
    console.log(`📩 PayPal Webhook 收到事件: ${eventType}`);
    
    switch (eventType) {
      case 'PAYMENT.CAPTURE.COMPLETED':
        // 支付完成
        return {
          event: eventType,
          status: 'completed',
          captureId: resource.id,
          amount: resource.amount.value,
          currency: resource.amount.currency_code,
          customId: resource.custom_id
        };
        
      case 'PAYMENT.CAPTURE.DENIED':
      case 'PAYMENT.CAPTURE.FAILED':
        // 支付失败
        return {
          event: eventType,
          status: 'failed',
          captureId: resource.id,
          reason: resource.reason || '支付失败'
        };
        
      case 'PAYMENT.CAPTURE.REFUNDED':
        // 退款完成
        return {
          event: eventType,
          status: 'refunded',
          captureId: resource.id,
          refundAmount: resource.amount.value
        };
        
      default:
        return {
          event: eventType,
          status: 'unknown',
          message: '未处理的事件类型'
        };
    }
  } catch (error) {
    console.error('❌ 处理 PayPal Webhook 失败:', error);
    return {
      error: error.message,
      status: 'error'
    };
  }
};

/**
 * 验证 Webhook 签名
 * @param {Object} headers 请求头
 * @param {string} body 请求体
 * @returns {boolean} 是否验证通过
 */
const verifyWebhookSignature = async (headers, body) => {
  try {
    if (!paypalClient) initializePayPal();

    const request = new paypal.webhooks.WebhooksVerifySignatureRequest();
    
    request.requestBody({
      transmission_id: headers['paypal-transmission-id'],
      transmission_time: headers['paypal-transmission-time'],
      cert_url: headers['paypal-cert-url'],
      auth_algo: headers['paypal-auth-algo'],
      transmission_sig: headers['paypal-transmission-sig'],
      webhook_id: process.env.PAYPAL_WEBHOOK_ID,
      webhook_event: JSON.parse(body)
    });

    const response = await paypalClient.execute(request);
    return response.result.verification_status === 'SUCCESS';
  } catch (error) {
    console.error('❌ 验证 PayPal Webhook 签名失败:', error);
    return false;
  }
};

/**
 * 创建退款
 * @param {string} captureId 捕获ID
 * @param {Object} refundData 退款数据
 * @returns {Promise<Object>} 退款结果
 */
const createRefund = async (captureId, refundData) => {
  try {
    if (!paypalClient) initializePayPal();

    const request = new paypal.payments.CapturesRefundRequest(captureId);
    
    const { amount, currency = 'USD', note = '退款' } = refundData;
    
    request.requestBody({
      amount: {
        value: amount.toFixed(2),
        currency_code: currency
      },
      note_to_payer: note,
      invoice_id: refundData.invoiceId
    });

    const response = await paypalClient.execute(request);
    const refund = response.result;
    
    console.log(`✅ PayPal 退款创建成功: ${refund.id}`);
    
    return {
      success: true,
      refundId: refund.id,
      status: refund.status,
      amount: refund.amount.value,
      currency: refund.amount.currency_code,
      createTime: refund.create_time
    };
  } catch (error) {
    console.error('❌ PayPal 退款创建失败:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

module.exports = {
  initializePayPal,
  createOrder,
  captureOrder,
  getOrderDetails,
  handleWebhook,
  verifyWebhookSignature,
  createRefund
};