const mongoose = require('mongoose');

/**
 * 课程/虚拟商品模型
 */
const CourseSchema = new mongoose.Schema({
  // 基础信息
  title: {
    type: String,
    required: [true, '课程标题不能为空'],
    trim: true,
    maxlength: [200, '标题不能超过200个字符']
  },
  slug: {
    type: String,
    required: true,
    unique: true,
    lowercase: true
  },
  description: {
    type: String,
    required: [true, '课程描述不能为空'],
    maxlength: [5000, '描述不能超过5000个字符']
  },
  shortDescription: {
    type: String,
    maxlength: [500, '简短描述不能超过500个字符']
  },
  
  // 定价信息
  price: {
    type: Number,
    required: [true, '价格不能为空'],
    min: [0, '价格不能为负数']
  },
  currency: {
    type: String,
    default: 'USD',
    enum: ['USD', 'CNY', 'EUR', 'GBP', 'JPY']
  },
  originalPrice: {
    type: Number,
    min: [0, '原价不能为负数']
  },
  discountPercentage: {
    type: Number,
    min: 0,
    max: 100,
    default: 0
  },
  
  // 商品类型
  type: {
    type: String,
    required: true,
    enum: [
      'course',      // 课程
      'ebook',       // 电子书
      'software',    // 软件
      'service',     // 服务
      'subscription' // 订阅
    ],
    default: 'course'
  },
  
  // 订阅相关（如果是订阅类型）
  subscriptionPlan: {
    interval: {
      type: String,
      enum: ['daily', 'weekly', 'monthly', 'quarterly', 'yearly']
    },
    intervalCount: {
      type: Number,
      default: 1
    },
    trialPeriodDays: {
      type: Number,
      default: 0
    }
  },
  
  // 内容信息
  content: {
    videoUrl: String,
    videoDuration: Number, // 分钟
    fileUrls: [{
      name: String,
      url: String,
      size: Number,
      type: String
    }],
    lessonCount: {
      type: Number,
      default: 0
    },
    totalDuration: {
      type: Number,
      default: 0
    }
  },
  
  // 封面图片
  coverImage: {
    url: String,
    alt: String,
    width: Number,
    height: Number
  },
  
  // 标签和分类
  categories: [{
    type: String,
    lowercase: true
  }],
  tags: [{
    type: String,
    lowercase: true
  }],
  
  // 讲师/作者信息
  instructor: {
    name: String,
    bio: String,
    avatar: String,
    email: String,
    socialLinks: {
      website: String,
      twitter: String,
      linkedin: String,
      github: String
    }
  },
  
  // 课程详情
  features: [String],
  requirements: [String],
  whatYouWillLearn: [String],
  targetAudience: [String],
  
  // 状态和管理
  status: {
    type: String,
    enum: ['draft', 'published', 'archived', 'coming_soon'],
    default: 'draft'
  },
  isFeatured: {
    type: Boolean,
    default: false
  },
  isFree: {
    type: Boolean,
    default: false
  },
  salesCount: {
    type: Number,
    default: 0
  },
  rating: {
    average: {
      type: Number,
      min: 0,
      max: 5,
      default: 0
    },
    count: {
      type: Number,
      default: 0
    },
    reviews: [{
      user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
      },
      rating: {
        type: Number,
        min: 1,
        max: 5
      },
      comment: String,
      createdAt: {
        type: Date,
        default: Date.now
      }
    }]
  },
  
  // 元数据
  metaTitle: String,
  metaDescription: String,
  keywords: [String],
  
  // 时间戳
  publishedAt: Date,
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// 索引
CourseSchema.index({ title: 'text', description: 'text' });
CourseSchema.index({ status: 1 });
CourseSchema.index({ type: 1 });
CourseSchema.index({ price: 1 });
CourseSchema.index({ createdAt: -1 });
CourseSchema.index({ 'instructor.name': 1 });
CourseSchema.index({ categories: 1 });
CourseSchema.index({ tags: 1 });

// 虚拟字段
CourseSchema.virtual('discountedPrice').get(function() {
  if (this.discountPercentage > 0) {
    return this.price * (1 - this.discountPercentage / 100);
  }
  return this.price;
});

CourseSchema.virtual('isDiscounted').get(function() {
  return this.discountPercentage > 0;
});

CourseSchema.virtual('formattedPrice').get(function() {
  const formatter = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: this.currency
  });
  return formatter.format(this.price);
});

CourseSchema.virtual('formattedDiscountedPrice').get(function() {
  const discountedPrice = this.discountedPrice;
  const formatter = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: this.currency
  });
  return formatter.format(discountedPrice);
});

// 保存前钩子
CourseSchema.pre('save', function(next) {
  // 自动生成 slug
  if (!this.slug && this.title) {
    this.slug = this.title
      .toLowerCase()
      .replace(/[^\w\s]/gi, '')
      .replace(/\s+/g, '-');
  }
  
  // 如果是免费课程，价格为0
  if (this.isFree) {
    this.price = 0;
  }
  
  // 更新原价
  if (this.discountPercentage > 0 && !this.originalPrice) {
    this.originalPrice = this.price;
  }
  
  this.updatedAt = Date.now();
  next();
});

// 静态方法
CourseSchema.statics.findPublished = function() {
  return this.find({ status: 'published' });
};

CourseSchema.statics.findFeatured = function() {
  return this.find({ status: 'published', isFeatured: true });
};

CourseSchema.statics.findByCategory = function(category) {
  return this.find({ 
    status: 'published',
    categories: { $regex: new RegExp(category, 'i') }
  });
};

CourseSchema.statics.findByInstructor = function(instructorName) {
  return this.find({ 
    status: 'published',
    'instructor.name': { $regex: new RegExp(instructorName, 'i') }
  });
};

CourseSchema.statics.search = function(query) {
  return this.find({
    $or: [
      { title: { $regex: new RegExp(query, 'i') } },
      { description: { $regex: new RegExp(query, 'i') } },
      { tags: { $regex: new RegExp(query, 'i') } },
      { categories: { $regex: new RegExp(query, 'i') } }
    ],
    status: 'published'
  });
};

// 实例方法
CourseSchema.methods.incrementSales = function() {
  this.salesCount += 1;
  return this.save();
};

CourseSchema.methods.addReview = function(userId, rating, comment) {
  const existingReviewIndex = this.rating.reviews.findIndex(
    review => review.user.toString() === userId.toString()
  );
  
  if (existingReviewIndex >= 0) {
    // 更新现有评价
    this.rating.reviews[existingReviewIndex].rating = rating;
    this.rating.reviews[existingReviewIndex].comment = comment;
    this.rating.reviews[existingReviewIndex].createdAt = Date.now();
  } else {
    // 添加新评价
    this.rating.reviews.push({
      user: userId,
      rating,
      comment
    });
  }
  
  // 重新计算平均分
  const totalRating = this.rating.reviews.reduce((sum, review) => sum + review.rating, 0);
  this.rating.average = totalRating / this.rating.reviews.length;
  this.rating.count = this.rating.reviews.length;
  
  return this.save();
};

CourseSchema.methods.getPreviewData = function() {
  return {
    id: this._id,
    title: this.title,
    slug: this.slug,
    shortDescription: this.shortDescription,
    price: this.price,
    discountedPrice: this.discountedPrice,
    isDiscounted: this.isDiscounted,
    discountPercentage: this.discountPercentage,
    coverImage: this.coverImage,
    instructor: this.instructor?.name,
    rating: this.rating.average,
    salesCount: this.salesCount,
    type: this.type
  };
};

const Course = mongoose.model('Course', CourseSchema);

module.exports = Course;