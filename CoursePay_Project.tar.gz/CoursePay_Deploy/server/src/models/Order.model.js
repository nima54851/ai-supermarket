const mongoose = require('mongoose');

/**
 * 订单模型
 */
const OrderSchema = new mongoose.Schema({
  // 订单基本信息
  orderNumber: {
    type: String,
    required: true,
    unique: true
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  email: {
    type: String,
    required: true,
    lowercase: true
  },
  
  // 商品信息
  items: [{
    course: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Course',
      required: true
    },
    name: String,
    type: {
      type: String,
      enum: ['course', 'ebook', 'software', 'service', 'subscription']
    },
    price: {
      type: Number,
      required: true,
      min: 0
    },
    quantity: {
      type: Number,
      required: true,
      min: 1,
      default: 1
    },
    subtotal: {
      type: Number,
      required: true,
      min: 0
    }
  }],
  
  // 价格信息
  subtotal: {
    type: Number,
    required: true,
    min: 0
  },
  discount: {
    type: Number,
    default: 0,
    min: 0
  },
  tax: {
    type: Number,
    default: 0,
    min: 0
  },
  shipping: {
    type: Number,
    default: 0,
    min: 0
  },
  total: {
    type: Number,
    required: true,
    min: 0
  },
  currency: {
    type: String,
    default: 'USD',
    enum: ['USD', 'CNY', 'EUR', 'GBP', 'JPY']
  },
  
  // 优惠信息
  couponCode: String,
  couponDiscount: {
    type: Number,
    default: 0,
    min: 0
  },
  
  // 支付信息
  paymentMethod: {
    type: String,
    enum: ['paypal', 'stripe', 'credit_card', 'bank_transfer', 'wallet'],
    default: 'paypal'
  },
  paymentStatus: {
    type: String,
    enum: ['pending', 'processing', 'completed', 'failed', 'refunded', 'cancelled'],
    default: 'pending'
  },
  
  // PayPal 支付信息
  paypal: {
    orderId: String,
    payerId: String,
    paymentId: String,
    captureId: String,
    status: String,
    payerEmail: String,
    payerName: String,
    paymentTime: Date,
    refundId: String,
    refundTime: Date,
    webhookEvents: [{
      eventType: String,
      eventId: String,
      timestamp: Date,
      data: mongoose.Schema.Types.Mixed
    }]
  },
  
  // 订阅信息（如果是订阅订单）
  subscription: {
    subscriptionId: String,
    planId: String,
    interval: String,
    currentPeriodStart: Date,
    currentPeriodEnd: Date,
    status: {
      type: String,
      enum: ['active', 'canceled', 'past_due', 'unpaid', 'trialing'],
      default: 'active'
    },
    cancelAtPeriodEnd: {
      type: Boolean,
      default: false
    }
  },
  
  // 订单状态
  orderStatus: {
    type: String,
    enum: ['pending', 'confirmed', 'processing', 'completed', 'cancelled', 'refunded'],
    default: 'pending'
  },
  
  // 客户信息
  customer: {
    firstName: String,
    lastName: String,
    company: String,
    address: {
      street: String,
      city: String,
      state: String,
      postalCode: String,
      country: String
    },
    phone: String
  },
  
  // 发票信息
  invoice: {
    number: String,
    issuedAt: Date,
    dueDate: Date,
    paidAt: Date,
    pdfUrl: String
  },
  
  // 备注
  notes: String,
  adminNotes: String,
  
  // 交付状态（虚拟商品）
  delivery: {
    status: {
      type: String,
      enum: ['pending', 'processing', 'delivered', 'failed'],
      default: 'pending'
    },
    deliveredAt: Date,
    accessGranted: {
      type: Boolean,
      default: false
    },
    accessCode: String,
    downloadLinks: [{
      name: String,
      url: String,
      expiresAt: Date
    }],
    emailSent: {
      type: Boolean,
      default: false
    },
    emailSentAt: Date
  },
  
  // 退款信息
  refund: {
    requested: {
      type: Boolean,
      default: false
    },
    requestedAt: Date,
    reason: String,
    amount: Number,
    processedAt: Date,
    processedBy: String,
    status: {
      type: String,
      enum: ['pending', 'approved', 'rejected', 'completed'],
      default: 'pending'
    }
  },
  
  // 时间戳
  expiresAt: Date, // 订单过期时间（如15分钟后）
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// 索引
OrderSchema.index({ orderNumber: 1 });
OrderSchema.index({ user: 1 });
OrderSchema.index({ email: 1 });
OrderSchema.index({ 'paypal.orderId': 1 });
OrderSchema.index({ 'paypal.paymentId': 1 });
OrderSchema.index({ paymentStatus: 1 });
OrderSchema.index({ orderStatus: 1 });
OrderSchema.index({ createdAt: -1 });
OrderSchema.index({ total: 1 });
OrderSchema.index({ 'subscription.subscriptionId': 1 });

// 虚拟字段
OrderSchema.virtual('itemCount').get(function() {
  return this.items.reduce((sum, item) => sum + item.quantity, 0);
});

OrderSchema.virtual('isPaid').get(function() {
  return this.paymentStatus === 'completed';
});

OrderSchema.virtual('isRefunded').get(function() {
  return this.paymentStatus === 'refunded';
});

OrderSchema.virtual('isCancelled').get(function() {
  return this.orderStatus === 'cancelled';
});

OrderSchema.virtual('isDelivered').get(function() {
  return this.delivery.status === 'delivered';
});

OrderSchema.virtual('customerName').get(function() {
  if (this.customer?.firstName && this.customer?.lastName) {
    return `${this.customer.firstName} ${this.customer.lastName}`;
  }
  return this.email;
});

OrderSchema.virtual('formattedTotal').get(function() {
  const formatter = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: this.currency
  });
  return formatter.format(this.total);
});

// 保存前钩子
OrderSchema.pre('save', function(next) {
  // 生成订单号
  if (!this.orderNumber) {
    const timestamp = Date.now().toString();
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    this.orderNumber = `ORD-${timestamp.slice(-9)}-${random}`;
  }
  
  // 生成发票号
  if (!this.invoice?.number && this.paymentStatus === 'completed') {
    this.invoice.number = `INV-${this.orderNumber}`;
    this.invoice.issuedAt = new Date();
    this.invoice.dueDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30天后
  }
  
  // 如果支付完成，更新订单状态
  if (this.paymentStatus === 'completed' && this.orderStatus === 'pending') {
    this.orderStatus = 'confirmed';
  }
  
  // 如果订单确认，开始处理交付
  if (this.orderStatus === 'confirmed' && this.delivery.status === 'pending') {
    this.delivery.status = 'processing';
  }
  
  // 自动计算商品小计
  if (this.items && this.items.length > 0) {
    this.items.forEach(item => {
      if (!item.subtotal) {
        item.subtotal = item.price * item.quantity;
      }
    });
  }
  
  // 自动计算总计
  if (!this.subtotal && this.items && this.items.length > 0) {
    this.subtotal = this.items.reduce((sum, item) => sum + item.subtotal, 0);
  }
  
  if (!this.total && this.subtotal) {
    this.total = this.subtotal - this.discount - this.couponDiscount + this.tax + this.shipping;
  }
  
  this.updatedAt = Date.now();
  next();
});

// 静态方法
OrderSchema.statics.findByUser = function(userId) {
  return this.find({ user: userId }).sort({ createdAt: -1 });
};

OrderSchema.statics.findByEmail = function(email) {
  return this.find({ email: email.toLowerCase() }).sort({ createdAt: -1 });
};

OrderSchema.statics.findByPayPalOrderId = function(orderId) {
  return this.findOne({ 'paypal.orderId': orderId });
};

OrderSchema.statics.findPendingOrders = function() {
  return this.find({ 
    paymentStatus: 'pending',
    expiresAt: { $gt: new Date() }
  });
};

OrderSchema.statics.generateSalesReport = async function(startDate, endDate) {
  const matchStage = {
    createdAt: {
      $gte: new Date(startDate),
      $lte: new Date(endDate)
    },
    paymentStatus: 'completed'
  };
  
  const result = await this.aggregate([
    { $match: matchStage },
    {
      $group: {
        _id: null,
        totalOrders: { $sum: 1 },
        totalRevenue: { $sum: '$total' },
        averageOrderValue: { $avg: '$total' },
        itemsSold: { $sum: { $sum: '$items.quantity' } }
      }
    },
    {
      $project: {
        _id: 0,
        totalOrders: 1,
        totalRevenue: { $round: ['$totalRevenue', 2] },
        averageOrderValue: { $round: ['$averageOrderValue', 2] },
        itemsSold: 1
      }
    }
  ]);
  
  return result[0] || {
    totalOrders: 0,
    totalRevenue: 0,
    averageOrderValue: 0,
    itemsSold: 0
  };
};

// 实例方法
OrderSchema.methods.completePayment = async function(paymentData) {
  this.paymentStatus = 'completed';
  this.paypal = {
    ...this.paypal,
    orderId: paymentData.orderId,
    payerId: paymentData.payer?.id,
    paymentId: paymentData.captureId,
    captureId: paymentData.captureId,
    status: paymentData.status,
    payerEmail: paymentData.payer?.email,
    payerName: paymentData.payer?.name,
    paymentTime: new Date()
  };
  
  // 设置发票支付时间
  this.invoice.paidAt = new Date();
  
  return this.save();
};

OrderSchema.methods.processRefund = async function(refundData, processedBy) {
  this.paymentStatus = 'refunded';
  this.orderStatus = 'refunded';
  this.refund = {
    requested: true,
    requestedAt: new Date(),
    reason: refundData.reason,
    amount: refundData.amount,
    processedAt: new Date(),
    processedBy: processedBy,
    status: 'completed'
  };
  
  this.paypal.refundId = refundData.refundId;
  this.paypal.refundTime = new Date();
  
  return this.save();
};

OrderSchema.methods.grantAccess = async function(accessData = {}) {
  this.delivery.accessGranted = true;
  this.delivery.status = 'delivered';
  this.delivery.deliveredAt = new Date();
  
  if (accessData.accessCode) {
    this.delivery.accessCode = accessData.accessCode;
  }
  
  if (accessData.downloadLinks) {
    this.delivery.downloadLinks = accessData.downloadLinks;
  }
  
  return this.save();
};

OrderSchema.methods.sendDeliveryEmail = async function() {
  this.delivery.emailSent = true;
  this.delivery.emailSentAt = new Date();
  return this.save();
};

OrderSchema.methods.cancelOrder = async function(reason = '用户取消') {
  if (this.paymentStatus === 'pending') {
    this.paymentStatus = 'cancelled';
    this.orderStatus = 'cancelled';
    this.notes = `订单取消原因: ${reason}`;
    return this.save();
  }
  
  throw new Error('只有待支付订单可以取消');
};

const Order = mongoose.model('Order', OrderSchema);

module.exports = Order;