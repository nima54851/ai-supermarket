const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const dotenv = require('dotenv');
const winston = require('winston');
const rateLimit = require('express-rate-limit');
const RedisStore = require('rate-limit-redis');
const redis = require('redis');

// 加载环境变量
dotenv.config();

// 创建 Express 应用
const app = express();

// 配置 Winston 日志
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      )
    }),
    new winston.transports.File({ 
      filename: 'logs/error.log', 
      level: 'error' 
    }),
    new winston.transports.File({ 
      filename: 'logs/combined.log' 
    })
  ]
});

// Redis 客户端
let redisClient;
let redisRateLimitStore;

if (process.env.REDIS_URL) {
  redisClient = redis.createClient({
    url: process.env.REDIS_URL
  });
  
  redisClient.on('error', (err) => {
    logger.error('Redis 连接错误:', err);
  });
  
  redisClient.connect().then(() => {
    logger.info('Redis 连接成功');
    
    // 配置 Redis 存储的速率限制
    redisRateLimitStore = new RedisStore({
      sendCommand: (...args) => redisClient.sendCommand(args)
    });
  }).catch(err => {
    logger.error('Redis 连接失败:', err);
  });
}

// 中间件配置
app.use(helmet()); // 安全头部
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  credentials: true
}));
app.use(morgan('combined', { 
  stream: { 
    write: message => logger.info(message.trim()) 
  } 
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// 视图引擎
app.set('view engine', 'ejs');
app.set('views', './views');

// 静态文件
app.use(express.static('public'));

// 速率限制
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15分钟
  max: process.env.RATE_LIMIT_MAX ? parseInt(process.env.RATE_LIMIT_MAX) : 100,
  message: { 
    error: '请求过于频繁，请稍后再试' 
  },
  standardHeaders: true,
  legacyHeaders: false,
  store: redisRateLimitStore
});

app.use(limiter);

// API 路由前缀
const API_PREFIX = process.env.API_PREFIX || '/api/v1';

// 导入路由
const paymentRoutes = require('./routes/payment.routes');

// 注册路由
app.use(`${API_PREFIX}/payment`, paymentRoutes);

// 健康检查端点
app.get('/health', (req, res) => {
  const healthcheck = {
    uptime: process.uptime(),
    timestamp: Date.now(),
    status: 'OK',
    checks: {
      redis: redisClient ? 'connected' : 'not configured',
      database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
      memory: process.memoryUsage()
    }
  };
  
  try {
    res.status(200).json(healthcheck);
  } catch (error) {
    healthcheck.status = 'ERROR';
    healthcheck.error = error.message;
    res.status(503).json(healthcheck);
  }
});

// API 文档页面
app.get('/docs', (req, res) => {
  res.render('docs', {
    title: 'CoursePay API 文档',
    apiBaseUrl: `${req.protocol}://${req.get('host')}${API_PREFIX}`
  });
});

// 首页
app.get('/', (req, res) => {
  res.render('index', {
    title: 'CoursePay - 课程销售平台',
    description: '销售课程、电子书、软件等虚拟商品的在线平台',
    features: [
      '支持 PayPal 支付',
      '自动化内容交付',
      '会员订阅系统',
      '多种商品类型支持'
    ]
  });
});

// 404 处理
app.use((req, res) => {
  res.status(404).json({
    error: '未找到请求的资源',
    path: req.path,
    method: req.method,
    timestamp: new Date().toISOString()
  });
});

// 错误处理中间件
app.use((err, req, res, next) => {
  logger.error('服务器错误:', err);
  
  const statusCode = err.statusCode || 500;
  const message = err.message || '内部服务器错误';
  
  res.status(statusCode).json({
    error: message,
    ...(process.env.NODE_ENV === 'development' && { 
      stack: err.stack 
    })
  });
});

// 数据库连接
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    logger.info('MongoDB 连接成功');
  } catch (error) {
    logger.error('MongoDB 连接失败:', error);
    process.exit(1);
  }
};

// 启动服务器
const startServer = async () => {
  try {
    // 连接数据库
    await connectDB();
    
    // 初始化 PayPal 服务
    const paypalService = require('./services/paypal.service');
    paypalService.initializePayPal();
    
    const PORT = process.env.PORT || 3000;
    const server = app.listen(PORT, () => {
      logger.info(`🚀 CoursePay 服务已启动`);
      logger.info(`📍 本地地址: http://localhost:${PORT}`);
      logger.info(`📚 API 文档: http://localhost:${PORT}/docs`);
      logger.info(`🏥 健康检查: http://localhost:${PORT}/health`);
      logger.info(`💰 PayPal 收款账户: ${process.env.PAYPAL_MODE === 'production' ? 'yinanzo@hotmail.com (生产环境)' : '沙盒环境'}`);
      logger.info(`🛠️  环境: ${process.env.NODE_ENV || 'development'}`);
    });
    
    // 优雅关闭
    const gracefulShutdown = () => {
      logger.info('收到关闭信号，正在优雅关闭...');
      
      server.close(async () => {
        logger.info('HTTP 服务器已关闭');
        
        // 关闭数据库连接
        await mongoose.connection.close();
        logger.info('MongoDB 连接已关闭');
        
        // 关闭 Redis 连接
        if (redisClient) {
          await redisClient.quit();
          logger.info('Redis 连接已关闭');
        }
        
        process.exit(0);
      });

      // 如果服务器在10秒内没有关闭，强制退出
      setTimeout(() => {
        logger.error('强制关闭超时，强制退出');
        process.exit(1);
      }, 10000);
    };

    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
    
  } catch (error) {
    logger.error('服务器启动失败:', error);
    process.exit(1);
  }
};

// 如果是直接运行此文件，启动服务器
if (require.main === module) {
  startServer();
}

module.exports = app;