#!/usr/bin/env python3
"""
CoursePay本地启动器 - 自动检测端口并启动
"""

import socket
import os
import sys
import time
from http.server import HTTPServer, SimpleHTTPRequestHandler
import webbrowser

def find_available_port(start_port=3000, max_port=4000):
    """寻找可用的端口"""
    for port in range(start_port, max_port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.1)
            if sock.connect_ex(('localhost', port)) != 0:
                sock.close()
                return port
            sock.close()
        except:
            continue
    return 3000  # 默认端口

class CoursePayHandler(SimpleHTTPRequestHandler):
    """自定义处理器，添加日志"""
    def do_GET(self):
        print(f"🔗 [{time.strftime('%H:%M:%S')}] 请求: {self.path}")
        return super().do_GET()
    
    def log_message(self, format, *args):
        print(f"📡 [{time.strftime('%H:%M:%S')}] {self.address_string()} - {format % args}")

def start_server():
    """启动HTTP服务器"""
    print("=" * 50)
    print("🎯 CoursePay 本地服务器")
    print("=" * 50)
    
    # 确保在正确目录
    os.chdir('/root/.openclaw/workspace/CoursePay')
    
    # 查找可用端口
    port = find_available_port(3001, 4000)
    print(f"🚀 启动端口: {port}")
    
    # 启动服务器
    server_address = ('', port)
    httpd = HTTPServer(server_address, CoursePayHandler)
    
    # 显示访问信息
    print("\n✅ 服务器已启动！")
    print(f"   🔗 主地址: http://localhost:{port}")
    print(f"   🔗 本地地址: http://127.0.0.1:{port}")
    
    print("\n📁 可用页面:")
    print(f"   1. 主页: http://localhost:{port}/index.html")
    print(f"   2. 验证页: http://localhost:{port}/check.html") 
    print(f"   3. 测试页: http://localhost:{port}/test.html")
    print(f"   4. 文档: http://localhost:{port}/README.md")
    
    print(f"\n📊 测试连接...")
    try:
        import urllib.request
        test_url = f'http://localhost:{port}/check.html'
        resp = urllib.request.urlopen(test_url, timeout=2)
        print(f"✅ HTTP {resp.status} - 连接正常")
        
        # 尝试自动打开浏览器（可选）
        # print(f"\n🌐 尝试在浏览器中打开...")
        # webbrowser.open(test_url)
        
    except Exception as e:
        print(f"❌ 测试连接失败: {e}")
    
    print(f"\n🔄 服务器运行中...")
    print("📌 按 Ctrl+C 停止服务器")
    print("=" * 50)
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 服务器已停止")
        httpd.server_close()

if __name__ == "__main__":
    start_server()