#!/bin/bash

# CoursePay 启动脚本
# 使用方法: ./start.sh [development|production]

set -e

ENV=${1:-development}

echo "🚀 启动 CoursePay 课程销售平台 ($ENV 环境)..."

# 检查 Node.js
if ! command -v node &> /dev/null; then
    echo "❌ 需要 Node.js 但未安装"
    exit 1
fi

echo "📦 检查 Node.js 版本..."
NODE_VERSION=$(node --version | cut -d'v' -f2)
MAJOR_VERSION=$(echo $NODE_VERSION | cut -d'.' -f1)

if [ $MAJOR_VERSION -lt 18 ]; then
    echo "❌ 需要 Node.js 18+，当前版本: $NODE_VERSION"
    exit 1
fi

echo "✅ Node.js 版本: $NODE_VERSION"

# 切换到 server 目录
cd "$(dirname "$0")/server"

# 检查依赖
echo "📦 检查依赖..."
if [ ! -d "node_modules" ]; then
    echo "📥 安装依赖..."
    npm install
fi

# 检查环境变量
echo "🔧 检查环境变量..."
if [ ! -f ".env" ]; then
    if [ -f "../.env.example" ]; then
        echo "📄 复制环境变量示例..."
        cp ../.env.example .env
        echo "⚠️  请编辑 .env 文件配置 PayPal 和其他设置"
        echo "    PayPal 收款账户: yinanzo@hotmail.com"
        exit 1
    else
        echo "❌ 未找到环境变量示例文件"
        exit 1
    fi
fi

# 检查数据库
echo "🗄️  检查数据库..."
if ! command -v mongod &> /dev/null; then
    echo "⚠️  MongoDB 未安装，可能需要手动启动"
fi

# 检查 Redis
echo "🔴 检查 Redis..."
if ! command -v redis-cli &> /dev/null; then
    echo "⚠️  Redis 未安装，可能需要手动启动"
fi

# 启动服务
echo "🚀 启动服务..."
case $ENV in
    development)
        echo "🛠️  启动开发环境..."
        npm run dev
        ;;
    production)
        echo "🏭 启动生产环境..."
        
        # 检查 PM2
        if ! command -v pm2 &> /dev/null; then
            echo "📦 安装 PM2..."
            npm install -g pm2
        fi
        
        # 使用 PM2 启动
        pm2 start src/app.js --name coursepay --watch
        
        echo "✅ 服务已启动"
        echo ""
        echo "📊 查看日志: pm2 logs coursepay"
        echo "📈 查看状态: pm2 status"
        echo "🔧 重启服务: pm2 restart coursepay"
        echo "🛑 停止服务: pm2 stop coursepay"
        ;;
    *)
        echo "❌ 未知环境: $ENV"
        echo "用法: ./start.sh [development|production]"
        exit 1
        ;;
esac