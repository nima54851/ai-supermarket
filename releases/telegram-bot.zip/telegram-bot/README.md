# 📱 Telegram号码查询机器人

基于 Telegram Bot 的实时手机号码归属地查询系统，支持批量查询、数据库缓存、7×24小时云端运行。

## ✨ 功能特性
- 实时查询，响应 < 2秒
- 全国号码数据库（持续更新）
- 批量查询支持
- 7×24小时 GitHub Actions 云端运行（免费）
- Telegram Bot 一条命令启动

## 💰 价格
¥29/月（含部署 + 技术支持）
PayPal: paypalyinanzo@hotmail.com

## 🚀 快速部署

### 前置要求
- Python 3.11+
- Telegram Bot Token（@BotFather 申请）
- GitHub 账号

### 步骤 1：申请 Telegram Bot
1. 打开 Telegram，搜索 @BotFather
2. 发送 `/newbot`
3. 按提示填写机器人名称和用户名
4. 复制获得的 Token（如 `123456789:ABCdef...`）

### 步骤 2：部署到 Railway（推荐）
1. 注册 https://railway.app
2. New Project → Deploy from GitHub → 选择本仓库
3. 添加环境变量 `BOT_TOKEN=你的Token`
4. 等待部署完成，访问分配的 URL

### 步骤 3：或者用 GitHub Actions 7×24运行
1. Fork 本仓库
2. Settings → Secrets → 添加 `BOT_TOKEN`
3. 修改 `phone-lookup.yml` workflow 中的 token 引用
4. 推送触发，Bot 即上线

## 📁 文件说明
- `bot.py` — Telegram Bot 主程序（python-telegram-bot v20）
- `server.py` — Flask Webhook 服务器（可选）
- `phone_data.py` — 号码数据库查询模块
- `requirements.txt` — Python 依赖

## 🤖 使用方法
用户发送手机号（如 `13800138000`），Bot 自动回复归属地信息。

## 🔧 本地运行
```bash
pip install -r requirements.txt
export BOT_TOKEN="你的Token"
python3 bot.py
```

## 🆘 技术支持
邮件: nima54851@gmail.com
Telegram: @diquchaxun78_bot
