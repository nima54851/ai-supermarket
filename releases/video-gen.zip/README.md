# AI视频生成助手

🎬 文字转视频 | AI配音 | 多风格模板 | ¥99/月

## 💰 购买信息
PayPal: paypalyinanzo@hotmail.com
客服: @diquchaxun78_bot

## 🚀 快速开始
1. 付款后联系 @diquchaxun78_bot 发送截图
2. 确认后获得完整包下载链接

## 🆘 技术支持
Email: nima54851@gmail.com
Telegram: @diquchaxun78_bot
