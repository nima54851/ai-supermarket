# 🎭 AI漫剧生成系统

AI自动生成漫画/漫剧，脚本→分镜→渲染一条龙。

## ✨ 功能特性
- 脚本自动生成
- AI分镜
- 风格迁移
- 批量渲染

## 💰 价格
¥149/月
PayPal: paypalyinanzo@hotmail.com

## 💳 付款后解锁下载
1. 点击 PayPal 付款: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=paypalyinanzo@hotmail.com&item_name=AI漫剧生成系统&amount=149&currency_code=USD
2. 联系 @diquchaxun78_bot 发送付款截图
3. 确认后获得完整版下载链接

## 🆘 技术支持
Telegram: @diquchaxun78_bot
Email: nima54851@gmail.com
