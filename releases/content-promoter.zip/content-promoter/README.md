# 📣 AI 内容推流系统（专业版）

一键生成多平台推广文案，覆盖掘金、V2EX、Twitter、Reddit、CSDN，批量发布+数据追踪。

## ✨ 功能特性
- 🎯 6大平台同时发布（掘金/V2EX/Twitter/Reddit/CSDN/HackerNews）
- 🤖 AI 批量生成适配各平台风格的文案
- ⏰ 定时自动推流（GitHub Actions 调度）
- 📊 效果数据看板
- 🔄 一键多账号支持

## 💰 价格
¥199/月（含部署 + 技术支持 + 平台账号配置）
PayPal: paypalyinanzo@hotmail.com

## 🚀 快速部署
```bash
cd scripts
TOPIC="你的主题" python3 ai_review.py
```
或导入 GitHub Actions workflow 自动化运行。

## 📁 文件说明
- `SKILL.md` — AI Content Promoter 完整规范文档
- `scripts/` — 多平台批量发布脚本
- `prompts/` — 各平台 Prompt 模板

## 🆘 技术支持
邮件: nima54851@gmail.com | Telegram: @diquchaxun78_bot
