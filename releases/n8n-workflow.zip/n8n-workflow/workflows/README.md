# n8n 工作流模板说明

## 模板列表

### 1. GitHub Trending → AI 摘要 → Telegram 通知
- 文件: `github-trending-digest.json`
- 功能: 每天 9:00 爬取 GitHub Trending，AI 生成摘要，推送到 Telegram

### 2. 自动 Star GitHub 项目
- 文件: `auto-star.yml`

### 3. Telegram 电话号码查询 Bot
- 文件: `telegram-lookup.yml`

### 4. 每日 AI 行业报告
- 文件: `daily-report.yml`

## 导入方法
n8n → Workflows → Import from JSON → 粘贴文件内容 → Activate
