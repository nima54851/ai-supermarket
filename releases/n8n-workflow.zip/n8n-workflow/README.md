# 🔗 n8n 工作流自动化系统（专业版）

拖拽式 n8n 工作流，GitHub + Telegram + AI 全自动集成。

## ✨ 功能特性
- 🔌 4+ 开源工作流模板（可扩展至500+）
- ⚡ Webhook 触发 + 定时调度
- 🐍 支持自定义 Python 节点
- 📥 一键导入 n8n
- 🤖 AI + GitHub + Telegram 集成

## 💰 价格
¥149/月（含模板库更新 + 技术支持）
PayPal: paypalyinanzo@hotmail.com

## 🚀 快速部署
1. 注册 n8n.cloud 或本地 Docker 运行
2. n8n → Import → 导入 `workflows/` 下的 JSON 文件
3. 配置凭证（GitHub Token、Telegram Bot Token）
4. Activate 激活

## 📁 文件说明
- `SKILL.md` — n8n 完整使用规范
- `workflows/` — 可导入的 workflow JSON 文件

## 🆘 技术支持
邮件: nima54851@gmail.com | Telegram: @diquchaxun78_bot
