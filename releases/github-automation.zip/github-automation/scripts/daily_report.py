#!/usr/bin/env python3
"""
GitHub AI 日报生成器
爬取 Trending → 生成 AI 摘要 → 保存到 REPORT.md
"""
import requests, os, json
from datetime import datetime

TOKEN = os.environ.get('GITHUB_TOKEN', '')
headers = {'Authorization': f'token {TOKEN}'}

LANGUAGES = ['python', 'javascript', 'typescript', 'go', 'rust']

def get_trending(lang):
    url = f'https://api.github.com/search/repositories'
    params = {'q': f'language:{lang}', 'sort': 'stars', 'order': 'desc', 'per_page': 10}
    r = requests.get(url, headers=headers, params=params, timeout=15)
    return r.json().get('items', [])[:10]

def generate_report():
    report = f"# 📊 GitHub Trending 日报\n\n📅 {datetime.now().strftime('%Y-%m-%d')}\n\n"
    for lang in LANGUAGES:
        repos = get_trending(lang)
        report += f"## 🐍 {lang.upper()}\n\n"
        for repo in repos:
            report += f"- ⭐ **[{repo['full_name']}]({repo['html_url']})** — {repo.get('description','')}\n"
        report += "\n"
    return report

if __name__ == '__main__':
    report = generate_report()
    print(report)
    with open('REPORT.md', 'w') as f:
        f.write(report)
    print("✅ Report saved to REPORT.md")
