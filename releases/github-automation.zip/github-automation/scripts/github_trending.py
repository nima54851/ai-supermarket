#!/usr/bin/env python3
"""
GitHub Trending 爬虫 + AI 评论生成
每天自动运行，Star + 评论 GitHub 热门项目
"""
import requests, os, json
from datetime import datetime

GITHUB_TOKEN = os.environ.get('GITHUB_TOKEN', '')
HEADERS = {'Authorization': f'token {GITHUB_TOKEN}', 'Accept': 'application/vnd.github.v3+json'}

def get_trending(lang='python', since='daily'):
    url = f'https://api.github.com/search/repositories'
    params = {'q': f'language:{lang} created:>{datetime.now().strftime("%Y-%m-%d")}',
              'sort': 'stars', 'order': 'desc', 'per_page': 5}
    r = requests.get(url, headers=HEADERS, params=params, timeout=15)
    return r.json().get('items', [])[:5]

def star_repo(owner, repo):
    r = requests.put(f'https://api.github.com/repos/{owner}/{repo}/star',
                     headers=HEADERS, timeout=10)
    return r.status_code in (204, 304)

def post_comment(owner, repo, pr_number, body):
    r = requests.post(f'https://api.github.com/repos/{owner}/{repo}/issues/{pr_number}/comments',
                      headers=HEADERS, json={'body': body}, timeout=10)
    return r.status_code == 201

if __name__ == '__main__':
    repos = get_trending()
    for repo in repos:
        print(f"⭐ Starring: {repo['full_name']}")
        star_repo(repo['owner']['login'], repo['name'])
    print(f"Done. Starred {len(repos)} repos")
