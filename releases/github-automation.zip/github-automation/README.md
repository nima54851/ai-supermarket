# ⚡ GitHub Agent 自动化系统（专业版）

全自动 GitHub 运营助手：自动 Star、评论、追踪 Trending、生成 AI 日报，一条命令启动。

## ✨ 功能特性
- 🤖 GitHub Actions 云端 7×24 运行（免费额度）
- ⭐ 自动 Star 热门项目（按语言筛选）
- 💬 AI 生成评论（GPT/Claude 风格）
- 📊 GitHub Trending 日报自动生成推送
- 🔄 支持多 GitHub 账号并行运营
- 📈 数据看板：Star 数量、评论记录、日报表

## 💰 价格
¥99/月（含完整部署 + 技术支持）
PayPal: paypalyinanzo@hotmail.com

## 🚀 快速部署

### 前置要求
- GitHub 账号
- GitHub Personal Access Token（有 repo 权限）
- Python 3.11+

### 步骤 1：创建 GitHub Token
1. GitHub → Settings → Developer settings → Personal access tokens → Generate new token
2. 勾选: `repo`, `workflow`, `read:user`, `public_repo`
3. 复制 Token

### 步骤 2：Fork + 配置
1. Fork 本仓库到你的 GitHub
2. Settings → Secrets → 添加:
   - `GH_TOKEN` = 你的 GitHub PAT
   - `TELEGRAM_BOT_TOKEN` = 可选（Telegram 通知）
3. 修改 `.github/workflows/bot.yml` 中的 `GH_TOKEN` 引用

### 步骤 3：启动
推送任意提交到 main 分支，GitHub Actions 自动运行 Bot。

## 📁 文件说明
- `.github/workflows/bot.yml` — 7×24 长连接 Bot workflow
- `.github/workflows/daily-report.yml` — 每日 Trending 报告 workflow
- `scripts/github_trending.py` — Trending 爬虫 + 自动 Star/评论
- `scripts/daily_report.py` — AI 日报生成器

## 📅 自动运行时间表
| 时间 | 任务 |
|---|---|
| 每小时 | 检查 GitHub Trending |
| 每天 09:00 | Star 热门项目 + 发评论 |
| 每天 10:00 | 生成并推送日报 |

## 🆘 技术支持
邮件: nima54851@gmail.com
Telegram: @diquchaxun78_bot
