# 安装指南

## 第一步：下载文件
下载 zip 包并解压，得到以下文件：
- README.md     — 产品说明
- SETUP.md      — 部署指南
- workflow.json — n8n 工作流文件
- LICENSE       — MIT 许可证

## 第二步：导入 n8n
1. 打开 n8n：http://localhost:5678
2. 点击右上角「Import from File」
3. 选择 `workflow.json` 文件
4. 点击保存

## 第三步：配置凭证
在 n8n 中添加以下凭证：
- GitHub API Token（Settings → Developer settings → Personal access tokens）
- Email SMTP（如需要邮件推送）

## 第四步：修改配置
编辑工作流中的节点，填入你的 GitHub 用户名和目标仓库。

## 第五步：激活
点击右上角「Activate」，每天 09:00 自动运行！

## 需要帮助？
提交 Issue：https://github.com/nima54851/agent-studio/issues
